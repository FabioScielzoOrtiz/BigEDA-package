This is a package to carry out Exploratory Data Analysis, allowing to work on Big Data.

We are currently working to develop the package.