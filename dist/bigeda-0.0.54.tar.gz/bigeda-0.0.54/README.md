This is a package to carry out Exploratory Data Analysis, allowing to work on Big Data.

We are currently working to develop the package.

Usage:

```python
pip install BigEDA --upgrade
```

```python
import BigEDA
from BigEDA import package_status
```

```python
package_status()
```